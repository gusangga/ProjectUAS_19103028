package promhs;

/**
 *
 * @author I Gusti Ngurah Angga Putra Sukanta 19103028
 */
public class ProMHS {

    public static void main(String[] args) {
        new frmSIM().setVisible(true);
    }
    
}
